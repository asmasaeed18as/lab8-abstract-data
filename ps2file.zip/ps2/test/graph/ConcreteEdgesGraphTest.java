/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package graph;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests for ConcreteEdgesGraph.
 * 
 * This class runs the GraphInstanceTest tests against ConcreteEdgesGraph, as
 * well as tests for that particular implementation.
 * 
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteEdgesGraph implements Graph<String> {
    
    private final Set<String> vertices = new HashSet<>();
    private final List<Edge> edges = new ArrayList<>();
    
    // Abstraction function:
    //   Represents a directed, weighted graph using a set of vertices and a list of edges.
    // Representation invariant:
    //   - Vertices set and edges list must not be null.
    //   - Edges must only connect vertices present in the vertices set.
    // Safety from rep exposure:
    //   - vertices and edges are private and final.
    //   - vertices() returns an unmodifiable view of the vertices set.

    public ConcreteEdgesGraph() {
        checkRep();
    }

    private void checkRep() {
        for (Edge e : edges) {
            assert vertices.contains(e.getSource()) && vertices.contains(e.getTarget()) : 
                "Edge connects non-existent vertices";
        }
    }

    @Override
    public boolean add(String vertex) {
        boolean added = vertices.add(vertex);
        checkRep();
        return added;
    }

    @Override
    public int set(String source, String target, int weight) {
        add(source);
        add(target);
        
        for (Edge edge : edges) {
            if (edge.getSource().equals(source) && edge.getTarget().equals(target)) {
                int oldWeight = edge.getWeight();
                edges.remove(edge);
                if (weight > 0) edges.add(new Edge(source, target, weight));
                checkRep();
                return oldWeight;
            }
        }
        
        if (weight > 0) edges.add(new Edge(source, target, weight));
        checkRep();
        return 0;
    }

    @Override
    public boolean remove(String vertex) {
        boolean removed = vertices.remove(vertex);
        if (removed) edges.removeIf(edge -> edge.getSource().equals(vertex) || edge.getTarget().equals(vertex));
        checkRep();
        return removed;
    }

    @Override
    public Set<String> vertices() {
        return Collections.unmodifiableSet(vertices);
    }

    @Override
    public Map<String, Integer> sources(String target) {
        Map<String, Integer> sources = new HashMap<>();
        for (Edge edge : edges) {
            if (edge.getTarget().equals(target)) sources.put(edge.getSource(), edge.getWeight());
        }
        return Collections.unmodifiableMap(sources);
    }

    @Override
    public Map<String, Integer> targets(String source) {
        Map<String, Integer> targets = new HashMap<>();
        for (Edge edge : edges) {
            if (edge.getSource().equals(source)) targets.put(edge.getTarget(), edge.getWeight());
        }
        return Collections.unmodifiableMap(targets);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Vertices: " + vertices.toString() + "\nEdges:\n");
        for (Edge e : edges) {
            sb.append(e.toString()).append("\n");
        }
        return sb.toString();
    }
}
class Edge {
    
    private final String source;
    private final String target;
    private final int weight;
    
    // Abstraction function:
    //   Represents a directed, weighted edge from source to target.
    // Representation invariant:
    //   - Source and target must not be null.
    //   - Weight must be non-negative.
    // Safety from rep exposure:
    //   - All fields are private and final.

    public Edge(String source, String target, int weight) {
        this.source = source;
        this.target = target;
        this.weight = weight;
        checkRep();
    }

    private void checkRep() {
        assert source != null && target != null : "Source and target must not be null";
        assert weight >= 0 : "Weight must be non-negative";
    }

    public String getSource() { return source; }
    public String getTarget() { return target; }
    public int getWeight() { return weight; }

    @Override
    public String toString() {
        return source + " -> " + target + " (" + weight + ")";
    }
}
