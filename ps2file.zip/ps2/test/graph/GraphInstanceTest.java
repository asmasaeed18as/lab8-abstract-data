/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package graph;

import static org.junit.Assert.*;
import java.util.Collections;
import org.junit.Test;

public abstract class GraphInstanceTest {
    
    public abstract Graph<String> emptyInstance();

    @Test
    public void testInitialVerticesEmpty() {
        Graph<String> graph = emptyInstance();
        assertEquals("expected new graph to have no vertices", Collections.emptySet(), graph.vertices());
    }

    @Test
    public void testAddVertex() {
        Graph<String> graph = emptyInstance();
        assertTrue("expected to add vertex successfully", graph.add("A"));
        assertTrue("expected vertex 'A' in the graph", graph.vertices().contains("A"));
    }

    @Test
    public void testAddDuplicateVertex() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        assertFalse("expected duplicate add to return false", graph.add("A"));
    }

    @Test
    public void testSetEdge() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        graph.add("B");
        assertEquals("expected new edge weight to be 0", 0, graph.set("A", "B", 5));
        assertEquals("expected edge weight from 'A' to 'B' to be 5", 5, graph.set("A", "B", 5));
    }

    @Test
    public void testRemoveVertex() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        assertTrue("expected vertex 'A' to be removed", graph.remove("A"));
        assertFalse("expected vertex 'A' to be absent after removal", graph.vertices().contains("A"));
    }

    @Test
    public void testSourcesAndTargets() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        graph.add("B");
        graph.set("A", "B", 5);

        assertEquals("expected sources of 'B' to contain 'A' with weight 5", 
                     Integer.valueOf(5), graph.sources("B").get("A"));
        assertEquals("expected targets of 'A' to contain 'B' with weight 5", 
                     Integer.valueOf(5), graph.targets("A").get("B"));
    }
}
