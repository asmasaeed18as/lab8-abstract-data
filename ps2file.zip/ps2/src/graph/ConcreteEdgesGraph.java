/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * An implementation of Graph.
 * 
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteEdgesGraph implements Graph<String> {
    private Map<String, Map<String, Integer>> edges = new HashMap<>();
    
    @Override
    public boolean add(String vertex) {
        if (edges.containsKey(vertex)) {
            return false;
        }
        edges.put(vertex, new HashMap<>());
        return true;
    }

    @Override
    public boolean remove(String vertex) {
        if (!edges.containsKey(vertex)) {
            return false;
        }
        edges.remove(vertex);
        for (Map<String, Integer> targets : edges.values()) {
            targets.remove(vertex);
        }
        return true;
    }

    @Override
    public Set<String> vertices() {
        return edges.keySet();
    }

    @Override
    public int set(String source, String target, int weight) {
        if (!edges.containsKey(source) || !edges.containsKey(target)) {
            throw new IllegalArgumentException("Source or target vertex does not exist");
        }
        Map<String, Integer> sourceEdges = edges.get(source);
        Integer previousWeight = sourceEdges.put(target, weight);
        return previousWeight == null ? 0 : previousWeight;
    }

    @Override
    public Map<String, Integer> sources(String vertex) {
        if (!edges.containsKey(vertex)) {
            return Collections.emptyMap();
        }
        Map<String, Integer> sources = new HashMap<>();
        for (Map.Entry<String, Map<String, Integer>> entry : edges.entrySet()) {
            if (entry.getValue().containsKey(vertex)) {
                sources.put(entry.getKey(), entry.getValue().get(vertex));
            }
        }
        return sources;
    }

    @Override
    public Map<String, Integer> targets(String vertex) {
        return edges.getOrDefault(vertex, Collections.emptyMap());
    }

    /**
     * Provides a custom string representation of the graph
     * in the format {A={B=5}, B={}}.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("{");
        for (Map.Entry<String, Map<String, Integer>> vertexEntry : edges.entrySet()) {
            sb.append(vertexEntry.getKey()).append("={");
            Map<String, Integer> targetEdges = vertexEntry.getValue();
            for (Map.Entry<String, Integer> targetEntry : targetEdges.entrySet()) {
                sb.append(targetEntry.getKey()).append("=")
                  .append(targetEntry.getValue()).append(", ");
            }
            // Remove trailing comma and space
            if (!targetEdges.isEmpty()) {
                sb.setLength(sb.length() - 2);
            }
            sb.append("}, ");
        }
        // Remove trailing comma and space
        if (!edges.isEmpty()) {
            sb.setLength(sb.length() - 2);
        }
        sb.append("}");
        return sb.toString();
    }
}

/**
 * TODO specification
 * Immutable.
 * This class is internal to the rep of ConcreteEdgesGraph.
 * 
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Edge {
    
    private final String source;
    private final String target;
    private final int weight;
    
    // Abstraction function:
    //   Represents a directed, weighted edge from source to target.
    // Representation invariant:
    //   - Source and target must not be null.
    //   - Weight must be non-negative.
    // Safety from rep exposure:
    //   - All fields are private and final.

    public Edge(String source, String target, int weight) {
        this.source = source;
        this.target = target;
        this.weight = weight;
        checkRep();
    }

    private void checkRep() {
        assert source != null && target != null : "Source and target must not be null";
        assert weight >= 0 : "Weight must be non-negative";
    }

    public String getSource() { return source; }
    public String getTarget() { return target; }
    public int getWeight() { return weight; }

    @Override
    public String toString() {
        return source + " -> " + target + " (" + weight + ")";
    }
}

