package graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ConcreteVerticesGraph implements Graph<String> {

    private final List<Vertex> vertices = new ArrayList<>();

    public ConcreteVerticesGraph() {
        checkRep();
    }

    private void checkRep() {
        Set<String> uniqueLabels = new HashSet<>();
        for (Vertex v : vertices) {
            assert v != null : "Vertex should not be null";
            assert uniqueLabels.add(v.getLabel()) : "Duplicate vertex labels in graph";
        }
    }

    @Override
    public boolean add(String vertex) {
        for (Vertex v : vertices) {
            if (v.getLabel().equals(vertex)) {
                return false;
            }
        }
        vertices.add(new Vertex(vertex));
        checkRep();
        return true;
    }

    @Override
    public int set(String source, String target, int weight) {
        Vertex srcVertex = null, tgtVertex = null;

        // Ensure both source and target vertices exist, or create them
        for (Vertex v : vertices) {
            if (v.getLabel().equals(source)) srcVertex = v;
            if (v.getLabel().equals(target)) tgtVertex = v;
        }

        if (srcVertex == null) {
            srcVertex = new Vertex(source);
            vertices.add(srcVertex);
        }
        if (tgtVertex == null) {
            tgtVertex = new Vertex(target);
            vertices.add(tgtVertex);
        }

        int previousWeight = srcVertex.setTarget(target, weight);
        checkRep();
        return previousWeight;
    }

    @Override
    public boolean remove(String vertex) {
        for (Vertex v : vertices) {
            if (v.getLabel().equals(vertex)) {
                vertices.remove(v);
                for (Vertex other : vertices) {
                    other.removeTarget(vertex);
                }
                checkRep();
                return true;
            }
        }
        return false;
    }

    @Override
    public Set<String> vertices() {
        Set<String> vertexLabels = new HashSet<>();
        for (Vertex v : vertices) {
            vertexLabels.add(v.getLabel());
        }
        return Collections.unmodifiableSet(vertexLabels);
    }

    @Override
    public Map<String, Integer> sources(String target) {
        Map<String, Integer> sources = new HashMap<>();
        for (Vertex v : vertices) {
            Integer weight = v.getTargets().get(target);
            if (weight != null) {
                sources.put(v.getLabel(), weight);
            }
        }
        return Collections.unmodifiableMap(sources);
    }

    @Override
    public Map<String, Integer> targets(String source) {
        for (Vertex v : vertices) {
            if (v.getLabel().equals(source)) {
                return Collections.unmodifiableMap(v.getTargets());
            }
        }
        return Collections.emptyMap();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Vertex v : vertices) {
            sb.append(v.toString()).append("\n");
        }
        return sb.toString();
    }

    public static Graph<String> empty() {
        return new ConcreteVerticesGraph();
    }
}

class Vertex {

    private final String label;
    private final Map<String, Integer> targets = new HashMap<>();

    public Vertex(String label) {
        this.label = label;
        checkRep();
    }

    public String getLabel() {
        return label;
    }

    public Map<String, Integer> getTargets() {
        return Collections.unmodifiableMap(targets);
    }

    public int setTarget(String target, int weight) {
        if (weight == 0) {
            return targets.remove(target) != null ? weight : 0;
        } else {
            return targets.put(target, weight);
        }
    }

    public boolean removeTarget(String target) {
        return targets.remove(target) != null;
    }

    private void checkRep() {
        assert label != null : "Vertex label should not be null";
        for (Map.Entry<String, Integer> entry : targets.entrySet()) {
            assert entry.getKey() != null : "Target label should not be null";
            assert entry.getValue() >= 0 : "Weight should be non-negative";
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(label).append(" -> ");
        for (Map.Entry<String, Integer> entry : targets.entrySet()) {
            sb.append(entry.getKey()).append(" (").append(entry.getValue()).append(") ");
        }
        return sb.toString().trim();
    }
}
